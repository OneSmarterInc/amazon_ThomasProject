import Home from "./Components/Home";
import Navbar from "./Components/Navbar";
import Sidebar from "./Components/Sidebar";
import MainRoutes from "./MainRoutes";
import "./style.css";

function App() {
  return (
    <div className="App h-full w-screen bg-gray-100">
      <MainRoutes/>
    </div>
  );
}

export default App;

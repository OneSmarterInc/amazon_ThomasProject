import { Box, Flex, Text } from '@chakra-ui/react'
import React from 'react'
import { useNavigate } from 'react-router-dom'

const Footer = () => {

    const navigate = useNavigate();

  return (
    <Flex textAlign={"center"} justifyContent={"center"} gap={1} borderTop={"1px solid #d9d7d7"}>
          <Text
           
            fontSize={"16px"}
            textDecor={"underline"}
            cursor={"pointer"}
            color={"green"}
          >
            {" "}
            <a href="https://vendorcentral-amazon-dashboard-netsuiteapp.vercel.app/vendor.pdf" target="_blank" rel="noopener noreferrer">
            Amazon Vendor Central Site Terms
            </a>
          </Text>
          <Text fontSize={"16px"} color={"gray"}>
            2006-2024 Amazon.com, Inc. and its affiliates. All Rights Reserved.
            Vendor Central is a trademark of Amazon.com, Inc. or its affiliates.
          </Text>
        </Flex>
  )
}

export default Footer
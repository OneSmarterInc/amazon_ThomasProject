import React from "react";
import img1 from "../Assets/img11.png";
import img2 from "../Assets/img12.png";
import img3 from "../Assets/img13.png";
import img4 from "../Assets/img4.png";

import img21 from "../Assets/img21.png";
import img22 from "../Assets/img22.png";
import img23 from "../Assets/img23.png";
import img24 from "../Assets/img24.png";

import img31 from "../Assets/img31.png";
import img32 from "../Assets/img32.png";
import news from "../Assets/news.png";
import business from "../Assets/business.png";
import grow from "../Assets/grow.png";
import invoices from "../Assets/invoices.png";
import blocked from "../Assets/blocked.png";

import { Box, Flex, Image } from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const handleClick = (name) => {
    const newTab = window.open(`/new/${name}`, '_blank');
    if (newTab) {
      // Ensure the new tab loads the correct route
      newTab.onload = () => {
        newTab.location.href = window.location.origin + `/new/${name}`;
      };
    }
  };

  const navigate = useNavigate()
  

  return (
    <Box w={"100%"}>
      <Flex w={"80%"} m={"auto"} justifyContent={"space-between"} mt={2}>
        <Image
          onClick={()=>handleClick("news")}
          cursor={"pointer"}
          src={img1}
          w={"24%"}
        ></Image>
        <Image
          onClick={() => handleClick("blocked")}
          cursor={"pointer"}
          src={img2}
          w={"24%"}
        ></Image>
        <Image
          onClick={() => handleClick("listed_features")}
          cursor={"pointer"}
          src={img3}
          w={"24%"}
        ></Image>
        <Image cursor={"pointer"} src={img4} w={"24%"}></Image>
      </Flex>

      <Flex w={"80%"} m={"auto"} justifyContent={"space-between"} mt={2}>
        <Image
          onClick={() => handleClick("invoices")}
          cursor={"pointer"}
          src={img21}
          w={"24%"}
        ></Image>
        <Image cursor={"pointer"} src={img22} w={"24%"}></Image>
        <Image
          onClick={() => handleClick("grow")}
          cursor={"pointer"}
          src={img23}
          w={"24%"}
        ></Image>
        <Image
          onClick={() => handleClick("business")}
          cursor={"pointer"}
          src={img24}
          w={"24%"}
        ></Image>
      </Flex>

      <Flex w={"80%"} m={"auto"} gap={4} mt={2}>
        <Image cursor={"pointer"} src={img31} w={"24%"}></Image>
        <Image cursor={"pointer"} src={img32} w={"24%"}></Image>
      </Flex>
    </Box>
  );
};

export default Home;

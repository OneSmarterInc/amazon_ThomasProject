import {
  Box,
  Button,
  Flex,
  Input,
  Text,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
  VStack,
  Select,
} from "@chakra-ui/react";
import {
  TriangleUpIcon,
  TriangleDownIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
} from "@chakra-ui/icons";
import React, { useState } from "react";

import { initialData } from "./data";

const Items = () => {
  const [data, setData] = useState(initialData);
  const [entriesPerPage, setEntriesPerPage] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortConfig, setSortConfig] = useState({
    key: null,
    direction: "ascending",
  });
  const [currentPage, setCurrentPage] = useState(1);

  const { isOpen, onOpen, onClose } = useDisclosure();
  const [newData, setNewData] = useState({
    UPC: "",
    ASIN: "",
    Title: "",
    "Stock Keeping Unit": "",
    MSRP: "",
  });

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleSort = (key) => {
    let direction = "ascending";
    if (sortConfig.key === key && sortConfig.direction === "ascending") {
      direction = "descending";
    }
    setSortConfig({ key, direction });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewData({ ...newData, [name]: value });
  };

  const handleAddData = () => {
    setData([...data, newData]);
    setNewData({
      UPC: "",
      ASIN: "",
      Title: "",
      "Stock Keeping Unit": "",
      MSRP: "",
    });
    onClose();
  };

  const handlePreviousPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) =>
      Math.min(prevPage + 1, Math.ceil(filteredData.length / entriesPerPage))
    );
  };

  const sortedData = React.useMemo(() => {
    let sortableData = [...data];
    if (sortConfig.key !== null) {
      sortableData.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === "ascending" ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === "ascending" ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableData;
  }, [data, sortConfig]);

  const filteredData = sortedData.filter(
    (el) =>
      el.UPC.toLowerCase().includes(searchTerm.toLowerCase()) ||
      el.ASIN.toLowerCase().includes(searchTerm.toLowerCase()) ||
      el.Title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      el["Stock Keeping Unit"]
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      el.MSRP.toString().includes(searchTerm)
  );

  const paginatedData = filteredData.slice(
    (currentPage - 1) * entriesPerPage,
    currentPage * entriesPerPage
  );

  const renderSortIcon = (key) => {
    if (sortConfig.key === key) {
      return sortConfig.direction === "ascending" ? (
        <TriangleUpIcon />
      ) : (
        <TriangleDownIcon />
      );
    }
    return (
      <VStack gap={0}>
        <TriangleUpIcon color={"gray.300"} />
        <TriangleDownIcon color={"gray.300"} />
      </VStack>
    );
  };

  const totalPages = Math.ceil(filteredData.length / entriesPerPage);

  const Pagination = () => {
    const pageNumbers = [];
    for (let i = 1; i <= totalPages; i++) {
      pageNumbers.push(i);
    }

    const handlePageClick = (pageNumber) => {
      setCurrentPage(pageNumber);
    };

    const renderPageNumbers = () => {
      const maxPageNumbersToShow = 5;
      const currentIndex = currentPage - 1;
      const startIndex = Math.max(0, currentIndex - 2);
      const endIndex = Math.min(
        startIndex + maxPageNumbersToShow - 1,
        totalPages - 1
      );

      const pageNumbersToShow = pageNumbers.slice(startIndex, endIndex + 1);

      if (startIndex > 0) {
        pageNumbersToShow.unshift("...");
        pageNumbersToShow.unshift(1);
      }
      if (endIndex < totalPages - 1) {
        pageNumbersToShow.push("...");
        pageNumbersToShow.push(totalPages);
      }

      return pageNumbersToShow.map((number, index) =>
        number === "..." ? (
          <Text key={index}>...</Text>
        ) : (
          <Button
            size={"sm"}
            key={index}
            bg={number === currentPage ? "blue.400" : "gray.200"}
            color={number === currentPage ? "white" : "black"}
            onClick={() => handlePageClick(number)}
          >
            {number}
          </Button>
        )
      );
    };

    const startEntry = (currentPage - 1) * entriesPerPage + 1;
    const endEntry = Math.min(currentPage * entriesPerPage, filteredData.length);

    return (
      <Flex justifyContent="space-between" alignItems="center" mt={4} gap={2}>
        <Text color={"blue.200"} >
          Showing {startEntry} to {endEntry} of {filteredData.length} entries
        </Text>
        <Flex w={"27%"} justifyContent={"flex-end"} gap={2} alignItems={"center"}>
          <ChevronLeftIcon
            fontSize={"25"}
            cursor={"pointer"}
            onClick={handlePreviousPage}
            isDisabled={currentPage === 1}
          />

          {renderPageNumbers()}

          <ChevronRightIcon
            fontSize={"25"}
            cursor={"pointer"}
            onClick={handleNextPage}
            isDisabled={currentPage === totalPages}
          />
        </Flex>
      </Flex>
    );
  };

  return (
    <Flex flexDir={"column"} w={"80%"} p={4} m={"auto"}>
      <Text fontSize={26} fontWeight={"600"} color={"#212529"} mb={5}>
        Items List
      </Text>
      <Flex w={"100%"} justifyContent={"space-between"}>
        <Flex w={"40%"} alignItems={"center"} mb={4}>
          <Select
            onChange={(e) => setEntriesPerPage(parseInt(e.target.value))}
            w={"18%"}
            mr={1}
            border={"1px solid gray"}
          >
            <option value="10">10</option>
            <option value="25">25</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </Select>
          <Text w={"30%"}>entries per page</Text>
          <Button
            w={"30%"}
            onClick={onOpen}
            size={"sm"}
            color={"white"}
            bg={"blue.400"}
          >
            Add New Item
          </Button>
        </Flex>

        <Flex mb={4} w={"20%"} alignSelf={"flex-end"} alignItems={"center"}>
          <Text mr={2}>Search:</Text>
          <Input
            type="text"
            border={"1px solid gray"}
            size={"sm"}
            value={searchTerm}
            onChange={handleSearch}
          />
        </Flex>
      </Flex>
      <Box maxH={"400px"} overflowY={"auto"}>
        <Table colorScheme="#212529" size={"sm"}>
          <Thead bg={"#EFEFEF"}>
            <Tr>
              <Th
                textTransform="none"
                cursor="pointer"
                onClick={() => handleSort("UPC")}
              >
                <Flex gap={1} alignItems={"center"}>
                  <span style={{ fontSize: "16px" }}>UPC</span>{" "}
                  {renderSortIcon("UPC")}
                </Flex>
              </Th>
              <Th
                textTransform="none"
                cursor="pointer"
                onClick={() => handleSort("ASIN")}
              >
                <Flex gap={1} alignItems={"center"}>
                  <span style={{ fontSize: "16px" }}>ASIN</span>{" "}
                  {renderSortIcon("ASIN")}
                </Flex>
              </Th>
              <Th
                textTransform="none"
                cursor="pointer"
                onClick={() => handleSort("Title")}
              >
                <Flex gap={1} alignItems={"center"}>
                  <span style={{ fontSize: "16px" }}>Title</span>{" "}
                  {renderSortIcon("Title")}
                </Flex>
              </Th>
              <Th
                textTransform="none"
                cursor="pointer"
                onClick={() => handleSort("Stock Keeping Unit")}
              >
                <Flex gap={1} alignItems={"center"}>
                  <span style={{ fontSize: "16px" }}>Stock Keeping Unit</span>{" "}
                  {renderSortIcon("Stock Keeping Unit")}
                </Flex>
              </Th>
              <Th
                textTransform="none"
                cursor="pointer"
                onClick={() => handleSort("MSRP")}
              >
                <Flex gap={1} alignItems={"center"} justifyContent={"flex-end"}>
                  <span style={{ fontSize: "16px" }}>MSRP</span>{" "}
                  {renderSortIcon("MSRP")}
                </Flex>
              </Th>
            </Tr>
          </Thead>
          <Tbody>
            {paginatedData.length > 0 ? (
              paginatedData.map((el, i) => (
                <Tr key={i}>
                  <Td>{el.UPC}</Td>
                  <Td textDecor={"underline"} color={"#0D6EFD"} ><a target="__blank" href={`https://www.amazon.com/Speed-Bag-Cotter-Pin-Swivel/dp/${el.ASIN}`}>{el.ASIN}</a></Td>
                  <Td>{el.Title}</Td>
                  <Td>{el["Stock Keeping Unit"]}</Td>
                  <Td textAlign={"right"}>{el.MSRP}</Td>
                </Tr>
              ))
            ) : (
              <Tr>
                <Td colSpan={5} textAlign="center">
                  No results found
                </Td>
              </Tr>
            )}
          </Tbody>
        </Table>
      </Box>

      <Pagination />

      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Add New Item</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Flex flexDir="column" gap={3}>
              <Input
                placeholder="UPC"
                name="UPC"
                value={newData.UPC}
                onChange={handleInputChange}
              />
              <Input
                placeholder="ASIN"
                name="ASIN"
                value={newData.ASIN}
                onChange={handleInputChange}
              />
              <Input
                placeholder="Title"
                name="Title"
                value={newData.Title}
                onChange={handleInputChange}
              />
              <Input
                placeholder="Stock Keeping Unit"
                name="Stock Keeping Unit"
                value={newData["Stock Keeping Unit"]}
                onChange={handleInputChange}
              />
              <Input
                placeholder="MSRP"
                name="MSRP"
                value={newData.MSRP}
                onChange={handleInputChange}
              />
            </Flex>
          </ModalBody>

          <ModalFooter>
            <Button colorScheme="blue" mr={3} onClick={handleAddData}>
              Add
            </Button>
            <Button variant="ghost" onClick={onClose}>
              Cancel
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Flex>
  );
};

export default Items;

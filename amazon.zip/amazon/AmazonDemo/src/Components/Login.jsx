import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Button,
  Divider,
  Flex,
  FormControl,
  FormLabel,
  Image,
  Input,
  Text,
  useToast,
} from "@chakra-ui/react";
import Cookies from "js-cookie";
import loginimg from "../Assets/loginimg.png";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({});
  const [loader, setLoader] = useState(false);

  const navigate = useNavigate();
  const toast = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    setErrors({});

    let newErrors = {};
    if (!email) newErrors.email = "Email is required";
    if (!password) newErrors.password = "Password is required";
    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      setLoader(true);

      if (
        email === "tsiegmund@harvestsports.com" &&
        password === "RobinOrange1205#"
      ) {
        Cookies.set("token", email, { expires: 7 });
        setLoader(false);
        toast({
          title: "Login successful",
          description: "You have successfully logged in.",
          status: "success",
          duration: 5000,
          isClosable: true,
          position: "top",
        });

        setEmail("");
        setPassword("");
        navigate("/");
      } else {
        setLoader(false);
        toast({
          title: "Login failed",
          description: "Email or password is incorrect.",
          status: "error",
          duration: 5000,
          isClosable: true,
          position: "top",
        });
      }
    }
  };

  return (
    <Flex>
      <Box
        w={"100%"}
        bg="white"
        minH="100vh"
        display="flex"
        justifyContent="center"
        alignItems="center"
        flexDirection="column"
      >
        <Box w="full" maxW="md" p={6} bg="white" rounded="md" shadow="md">
          <Image alignItems="center" margin="auto" src={loginimg} alt="" />
          <Text fontSize="2xl" fontWeight="bold" textAlign="start" mb={6}>
            Log In
          </Text>
          <Divider border={"0.5px solid gray"} mb={5} />
          <form onSubmit={handleSubmit}>
            <FormControl mb={4} isInvalid={errors.email}>
              <FormLabel htmlFor="email">Email</FormLabel>
              <Input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
              />
              {errors.email && (
                <Text color="red.500" fontSize="sm">
                  {errors.email}
                </Text>
              )}
            </FormControl>
            <FormControl mb={4} isInvalid={errors.password}>
              <FormLabel htmlFor="password">Password</FormLabel>
              <Input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
              />
              {errors.password && (
                <Text color="red.500" fontSize="sm">
                  {errors.password}
                </Text>
              )}
            </FormControl>

            <Flex gap={2} mb={5} alignItems={"center"}>
              <input
                style={{ height: "20px", width: "20px" }}
                type="checkbox"
              />{" "}
              <Text>Remember me?</Text>
            </Flex>

            <Button
              isLoading={loader}
              type="submit"
              w="full"
              bg={"yellow"}
              color={"black"}
              fontSize={"20px"}
            >
              Sign in
            </Button>
          </form>
        </Box>
       
      </Box>
    </Flex>
  );
};

export default Login;

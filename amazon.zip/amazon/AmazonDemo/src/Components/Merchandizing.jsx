import React from 'react'

const Merchandizing = () => {
  return (
    <div className='mb-[450px]'>
     <div className="mt-8">
        <div style={{backgroundColor:"#CFF4FC"}} className="mx-28 border  text-gray-800 py-4 px-6 ">
          <p className="text-start text-lg font-normal">
            Please contact your administrator for access to this page.
          </p>
        </div>
      </div> 
    </div>
  )
}

export default Merchandizing

import React from "react";
import Sidebar from "./Sidebar";
import Logo from "../Assets/Logo.png";
import { useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
const Navbar = () => {
  const navigate = useNavigate();
  const handleLogout = () => {
    Cookies.remove("token");
    navigate("/login");
  };
  return (
    <div className="bg-gray-800 text-white font-sans ">
      <header className="flex items-center justify-between pl-1 px-6">
        <div className="flex items-center">
          <div className=" border-0 border-r border-gray-100 border-opacity-50 ">
            <Sidebar />
          </div>

          <div onClick={()=>navigate("/")}  className="ml-4  flex items-center justify-between " style={{cursor:"pointer"}}>
            <img src={Logo} alt="Amazon Logo" className="" />
          </div>
        </div>
        <div className="flex items-center justify-evenly w-28">
          <button onClick={()=>navigate("/settings")} className="ml-4 text-white text-lg hover:text-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
            <i class="fa-solid fa-gear"></i>
          </button>
          <button onClick={()=>navigate("/settings")} className="ml-4 text-white text-lg hover:text-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
            <i class="fa-solid fa-circle-question"></i>
          </button>
        </div>
      </header>

      <hr className="text-gray-100 opacity-40" />
      <main className="p-3 text-center">
        <p className="text-sm text-gray-400">
          Add your favorite pages here by clicking the bookmark icon in the
          navigation menu.
        </p>
      </main>
      <div className="flex bg-gray-100 border-0 border-b justify-end items-center py-2">
        <button
          onClick={() => handleLogout()}
          className="bg-yellow-300 h-10  text-black rounded-md px-2 mx-24 border hover:border-black"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default Navbar;

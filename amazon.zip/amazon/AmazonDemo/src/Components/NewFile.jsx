import { Box, Image } from '@chakra-ui/react'
import React, { useEffect, useRef, useState } from 'react'
import news from "../Assets/news.png";
import business from "../Assets/business.png";
import grow from "../Assets/grow.png";
import invoices from "../Assets/invoices.png";
import blocked from "../Assets/blocked.png";
import { useParams } from 'react-router-dom';


const NewFile = () => {
  const {name} = useParams();
  const [url, setUrl] = useState(); 

  useEffect(()=>{
    console.log(name)
    if(name === "news"){
      setUrl(news)
    }
    else if(name === "business"){
      setUrl(business)
    }
    else if(name === "grow"){
      setUrl(grow)
    }
    else if(name === "invoices"){
      setUrl(invoices)
    }
    else if(name === "blocked"){
      setUrl(blocked)
    }
    else if(name === "listed_features"){
      setUrl(blocked)
    }
  },[])

  return (
    <Box bg={"white"}>
      <Image src={url} m={"auto"} w={"80%"} mb={5}></Image>
    </Box>
  )
}

export default NewFile
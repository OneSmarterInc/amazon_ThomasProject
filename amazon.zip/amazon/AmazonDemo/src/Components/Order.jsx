import {
    Box,
    Button,
    Flex,
    Input,
    Text,
    Table,
    Thead,
    Tbody,
    Tr,
    Th,
    Td,
    Modal,
    ModalOverlay,
    ModalContent,
    ModalHeader,
    ModalFooter,
    ModalBody,
    ModalCloseButton,
    useDisclosure,
    VStack,
  } from "@chakra-ui/react";
  import { TriangleUpIcon, TriangleDownIcon } from "@chakra-ui/icons";
  import React, { useState } from "react";
  
  const Order = () => {
    const initialData = [
      {
        "PO": "X302S49512M474",
        "Date": "06/18/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$369,485.73"
    },
    {
        "PO": "X302S49512M469",
        "Date": "06/17/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$604,071.59"
    },
    {
        "PO": "X302S49512M463",
        "Date": "06/13/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$536,179.17"
    },
    {
        "PO": "X302S49512M455",
        "Date": "06/12/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$639,069.31"
    },
    {
        "PO": "X302S49512M446",
        "Date": "06/11/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$660,709.11"
    },
    {
        "PO": "X302S49512M439",
        "Date": "06/10/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$556,056.83"
    },
    {
        "PO": "X302S49512M430",
        "Date": "06/03/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$665,552.25"
    },
    {
        "PO": "X302S49512M422",
        "Date": "05/31/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$673,875.60"
    },
    {
        "PO": "X302S49512M416",
        "Date": "05/29/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$807,674.60"
    },
    {
        "PO": "X302S49512M401",
        "Date": "05/21/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$951,853.27"
    },
    {
        "PO": "X302S49512M409",
        "Date": "05/20/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$959,006.24"
    },
    {
        "PO": "X302S49512M390",
        "Date": "05/16/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$857,109.24"
    },
    {
        "PO": "X302S49512M379",
        "Date": "05/08/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$849,043.32"
    },
    {
        "PO": "X302S49512M367",
        "Date": "05/03/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$805,900.81"
    },
    {
        "PO": "X302S49512M360",
        "Date": "05/01/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$798,791.35"
    },
    {
        "PO": "X302S49512M351",
        "Date": "04/26/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$970,359.51"
    },
    {
        "PO": "X302S49512M339",
        "Date": "04/22/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$964,537.47"
    },
    {
        "PO": "X302S49512M328",
        "Date": "04/16/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$958,903.57"
    },
    {
        "PO": "X302S49512M319",
        "Date": "04/15/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$977,929.51"
    },
    {
        "PO": "X302S49512M312",
        "Date": "04/11/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$974,938.80"
    },
    {
        "PO": "X302S49512M304",
        "Date": "04/04/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$868,841.79"
    },
    {
        "PO": "X302S49512M299",
        "Date": "04/02/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$676,572.75"
    },
    {
        "PO": "X302S49512M286",
        "Date": "03/28/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$873,428.94"
    },
    {
        "PO": "X302S49512M279",
        "Date": "03/26/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$889,367.92"
    },
    {
        "PO": "X302S49512M268",
        "Date": "03/22/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$917,718.17"
    },
    {
        "PO": "X302S49512M260",
        "Date": "03/20/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$840,300.29"
    },
    {
        "PO": "X302S49512M249",
        "Date": "03/15/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$925,743.38"
    },
    {
        "PO": "X302S49512M241",
        "Date": "03/13/2024",
        "Status": "Open",
        "Terms": "NET 90 Days",
        "Total": "$941,231.25"
    },
    {
        "PO": "X302S49512M238",
        "Date": "03/12/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$880,606.15"
    },
    {
        "PO": "X302S49512M229",
        "Date": "03/05/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$883,681.63"
    },
    {
        "PO": "X302S49512M220",
        "Date": "03/01/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$973,215.27"
    },
    {
        "PO": "X302S49512M216",
        "Date": "02/29/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$984,029.91"
    },
    {
        "PO": "X302S49512M212",
        "Date": "02/23/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$908,181.63"
    },
    {
        "PO": "X302S49512M207",
        "Date": "02/22/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$811,298.41"
    },
    {
        "PO": "X302S49512M199",
        "Date": "02/16/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$948,088.95"
    },
    {
        "PO": "X302S49512M196",
        "Date": "02/08/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$984,716.79"
    },
    {
        "PO": "X302S49512M193",
        "Date": "01/30/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$929,889.95"
    },
    {
        "PO": "X302S49512M185",
        "Date": "01/26/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$958,709.94"
    },
    {
        "PO": "X302S49512M171",
        "Date": "01/19/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$841,359.75"
    },
    {
        "PO": "X302S49512M163",
        "Date": "01/15/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$953,307.03"
    },
    {
        "PO": "X302S49512M150",
        "Date": "01/10/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$938,375.58"
    },
    {
        "PO": "X302S49512M139",
        "Date": "01/04/2024",
        "Status": "Paid In Full",
        "Terms": "NET 90 Days",
        "Total": "$894,680.91"
    }
    ];

    function convertDateFormat(dateString) {
      const [day, month, year] = dateString.split('-');
      
      return `${month}-${day}-${year}`;
    }
  
    const [data, setData] = useState(initialData);
    const [searchTerm, setSearchTerm] = useState("");
    const [sortConfig, setSortConfig] = useState({ key: null, direction: "ascending" });
    const [currentPage, setCurrentPage] = useState(1);
    const entriesPerPage = 20;
  
    const { isOpen, onOpen, onClose } = useDisclosure();
    const [newData, setNewData] = useState({
      PO: "",
      Date: "",
      Status: "",
      Terms: "",
      Total: "",
    });
  
    const handleSearch = (event) => {
      setSearchTerm(event.target.value);
    };
  
    const handleSort = (key) => {
      let direction = "ascending";
      if (sortConfig.key === key && sortConfig.direction === "ascending") {
        direction = "descending";
      }
      setSortConfig({ key, direction });
    };
  
    const handleInputChange = (e) => {
      const { name, value } = e.target;
      setNewData({ ...newData, [name]: value });
    };
  
    const handleAddData = () => {
      setData([...data, newData]);
      setNewData({
        PO: "",
        Date: "",
        Status: "",
        Terms: "",
        Total: "",
      });
      onClose();
    };
  
    const handlePreviousPage = () => {
      setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
    };
  
    const handleNextPage = () => {
      setCurrentPage((prevPage) => prevPage + 1);
    };
  
    const sortedData = React.useMemo(() => {
      let sortableData = [...data];
      if (sortConfig.key !== null) {
        sortableData.sort((a, b) => {
          if (a[sortConfig.key] < b[sortConfig.key]) {
            return sortConfig.direction === "ascending" ? -1 : 1;
          }
          if (a[sortConfig.key] > b[sortConfig.key]) {
            return sortConfig.direction === "ascending" ? 1 : -1;
          }
          return 0;
        });
      }
      return sortableData;
    }, [data, sortConfig]);
  
    const filteredData = sortedData.filter(
      (el) =>
        el.PO.toLowerCase().includes(searchTerm.toLowerCase()) ||
        el.Date.includes(searchTerm) ||
        el.Status.toLowerCase().includes(searchTerm.toLowerCase()) ||
        el.Terms.toLowerCase().includes(searchTerm.toLowerCase()) ||
        el.Total.toLowerCase().includes(searchTerm.toLowerCase())
    );
  
    const paginatedData = filteredData.slice(
      (currentPage - 1) * entriesPerPage,
      currentPage * entriesPerPage
    );
  
    const renderSortIcon = (key) => {
      if (sortConfig.key === key) {
        return sortConfig.direction === "ascending" ? (
          <TriangleUpIcon />
        ) : (
          <TriangleDownIcon />
        );
      }
      return (
        <VStack gap={0}>
          <TriangleUpIcon color={"gray.300"} />
          <TriangleDownIcon color={"gray.300"} />
        </VStack>
      );
    };
  
    return (
      <Flex flexDir={"column"} w={"80%"} p={4} m={"auto"}>
        <Text fontSize={26} fontWeight={"600"} color={"#212529"} mb={5}>Orders Year to Date</Text>
        <Flex w={"100%"} justifyContent={"space-between"}>
          <Button onClick={onOpen} mb={4} size={"sm"} color={"white"} bg={"blue.400"}>
            Add New Data
          </Button>
          <Flex mb={4} w={"20%"} alignSelf={"flex-end"} alignItems={"center"}>
            <Text mr={2}>Search:</Text>
            <Input
              type="text"
              border={"1px solid gray"}
              size={"sm"}
              value={searchTerm}
              onChange={handleSearch}
            />
          </Flex>
        </Flex>
  
        <Table colorScheme="#212529" size={"sm"} >
          <Thead bg={"#EFEFEF"}>
            <Tr>
             
              <Th textTransform="none"  cursor="pointer" onClick={() => handleSort("PO")}>
                <Flex gap={1} alignItems={"center"}><span style={{fontSize:"16px"}}>PO</span> {renderSortIcon("PO")}</Flex>
              </Th>
              <Th textTransform="none"  cursor="pointer" onClick={() => handleSort("Date")}>
                <Flex gap={1} alignItems={"center"}><span style={{fontSize:"16px"}}>Date</span> {renderSortIcon("Date")}</Flex>
              </Th>
              <Th textTransform="none"  cursor="pointer" onClick={() => handleSort("Status")}>
                <Flex gap={1} alignItems={"center"}><span style={{fontSize:"16px"}}>Status </span>{renderSortIcon("Status")}</Flex>
              </Th>
              <Th textTransform="none"  cursor="pointer" onClick={() => handleSort("Terms")}>
                <Flex gap={1} alignItems={"center"}><span style={{fontSize:"16px"}}>Terms</span> {renderSortIcon("Terms")}</Flex>
              </Th>
              <Th textTransform="none" cursor="pointer" onClick={() => handleSort("Total")}>
                <Flex gap={1} alignItems={"center"} ><span style={{fontSize:"16px"}}>Total</span> {renderSortIcon("Total")}</Flex>
              </Th>
            </Tr>
          </Thead>
          <Tbody>
            {paginatedData.length > 0 ? (
              paginatedData.map((el, i) => (
                <Tr key={i}>
                  <Td >{el.PO}</Td>
                  <Td >{el.Date}</Td>
                  <Td >{el.Status}</Td>
                  <Td >{el.Terms}</Td>
                  <Td >{el.Total}</Td>
                </Tr>
              ))
            ) : (
              <Tr>
                <Td colSpan={5} textAlign="center">
                  No results found
                </Td>
              </Tr>
            )}
          </Tbody>
        </Table>
        <Flex justifyContent="space-between" alignItems={"center"} w={"25%"} m={"auto"} mt={4}>
          <Button bg={"blue.400"} color={"white"} onClick={handlePreviousPage} isDisabled={currentPage === 1}>
            Previous
          </Button>
          <Text>Page {currentPage}</Text>
          <Button bg={"blue.400"} color={"white"} onClick={handleNextPage} isDisabled={currentPage * entriesPerPage >= filteredData.length}>
            Next
          </Button>
        </Flex>
  
        <Modal isOpen={isOpen} onClose={onClose}>
          <ModalOverlay />
          <ModalContent>
            <ModalHeader>Add New Data</ModalHeader>
            <ModalCloseButton />
            <ModalBody>
              <Flex flexDir="column" gap={3}>
                <Input placeholder="Date - DD-MM-YYYY" name="Date" value={newData.Date} onChange={handleInputChange} />
                <Input placeholder="PO" name="PO" value={newData.PO} onChange={handleInputChange} />
                <Input placeholder="Status" name="Status" value={newData.Status} onChange={handleInputChange} />
                <Input placeholder="Terms" name="Terms" value={newData.Terms} onChange={handleInputChange} />
                <Input placeholder="Total" name="Total" value={newData.Total} onChange={handleInputChange} />
              </Flex>
            </ModalBody>
  
            <ModalFooter>
              <Button colorScheme="blue" mr={3} onClick={handleAddData}>
                Add
              </Button>
              <Button variant="ghost" onClick={onClose}>
                Cancel
              </Button>
            </ModalFooter>
          </ModalContent>
        </Modal>
      </Flex>
    );
  };
  
  export default Order;
  
import React, { useState } from "react";
import {
  Box,
  Button,
  Flex,
  Input,
  Text,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
  VStack,
  Select,
  IconButton,
} from "@chakra-ui/react";
import {
  TriangleUpIcon,
  TriangleDownIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
} from "@chakra-ui/icons";
import { EditIcon, DeleteIcon, CheckIcon, CloseIcon } from "@chakra-ui/icons";

import { initialData } from "./paymentData";

const Payments = () => {
  const [data, setData] = useState(initialData);
  const [entriesPerPage, setEntriesPerPage] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortConfig, setSortConfig] = useState({
    key: null,
    direction: "ascending",
  });
  const [currentPage, setCurrentPage] = useState(1);

  const { isOpen, onOpen, onClose } = useDisclosure();
  const [newData, setNewData] = useState({
    "Paid Date": "",
    "Invoice #": "",
    Type: "",
    "Invoice Amount": "",
    Discounts: "",
    "Amount Paid": "",
  });

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleSort = (key) => {
    let direction = "ascending";
    if (sortConfig.key === key && sortConfig.direction === "ascending") {
      direction = "descending";
    }
    setSortConfig({ key, direction });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewData({ ...newData, [name]: value });
  };

  const handleAddData = () => {
    setData([...data, newData]);
    setNewData({
      "Paid Date": "",
      "Invoice #": "",
      "Type": "",
      "Invoice Amount": "",
      "Discounts": "",
      "Amount Paid": "",
    });
    onClose();
  };

  const handlePreviousPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) =>
      Math.min(prevPage + 1, Math.ceil(filteredData.length / entriesPerPage))
    );
  };

  const sortedData = React.useMemo(() => {
    let sortableData = [...data];
    if (sortConfig.key !== null) {
      sortableData.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === "ascending" ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === "ascending" ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableData;
  }, [data, sortConfig]);

  const filteredData = sortedData.filter(
    (el) =>
      el["Paid Date"].includes(searchTerm) ||
      el["Invoice #"].includes(searchTerm) ||
      el.Type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      el["Invoice Amount"].includes(searchTerm) ||
      el.Discounts.includes(searchTerm) ||
      el["Amount Paid"].includes(searchTerm)
  );

  const paginatedData = filteredData.slice(
    (currentPage - 1) * entriesPerPage,
    currentPage * entriesPerPage
  );

  const renderSortIcon = (key) => {
    if (sortConfig.key === key) {
      return sortConfig.direction === "ascending" ? (
        <TriangleUpIcon />
      ) : (
        <TriangleDownIcon />
      );
    }
    return (
      <VStack gap={0}>
        <TriangleUpIcon color={"gray.300"} />
        <TriangleDownIcon color={"gray.300"} />
      </VStack>
    );
  };

  const totalPages = Math.ceil(filteredData.length / entriesPerPage);

  const Pagination = () => {
    const pageNumbers = [];
    for (let i = 1; i <= totalPages; i++) {
      pageNumbers.push(i);
    }

    const handlePageClick = (pageNumber) => {
      setCurrentPage(pageNumber);
    };

    const renderPageNumbers = () => {
      const maxPageNumbersToShow = 5;
      const currentIndex = currentPage - 1;
      const startIndex = Math.max(0, currentIndex - 2);
      const endIndex = Math.min(
        startIndex + maxPageNumbersToShow - 1,
        totalPages - 1
      );

      const pageNumbersToShow = pageNumbers.slice(startIndex, endIndex + 1);

      if (startIndex > 0) {
        pageNumbersToShow.unshift("...");
        pageNumbersToShow.unshift(1);
      }
      if (endIndex < totalPages - 1) {
        pageNumbersToShow.push("...");
        pageNumbersToShow.push(totalPages);
      }

      return pageNumbersToShow.map((number, index) =>
        number === "..." ? (
          <Text key={index}>...</Text>
        ) : (
          <Button
            size={"sm"}
            key={index}
            bg={number === currentPage ? "blue.400" : "gray.200"}
            color={number === currentPage ? "white" : "black"}
            onClick={() => handlePageClick(number)}
          >
            {number}
          </Button>
        )
      );
    };

    const startEntry = (currentPage - 1) * entriesPerPage + 1;
    const endEntry = Math.min(currentPage * entriesPerPage, filteredData.length);

    return (
      <Flex justifyContent="space-between" alignItems="center" mt={4} gap={2}>
        <Text>
          Showing {startEntry} to {endEntry} of {filteredData.length} entries
        </Text>
        <Flex w={"27%"} justifyContent={"flex-end"} gap={2}>
          <ChevronLeftIcon
            fontSize={"25"}
            cursor={"pointer"}
            onClick={handlePreviousPage}
            isDisabled={currentPage === 1}
          />

          {renderPageNumbers()}

          <ChevronRightIcon
            fontSize={"25"}
            cursor={"pointer"}
            onClick={handleNextPage}
            isDisabled={currentPage === totalPages}
          />
        </Flex>
      </Flex>
    );
  };

  

  function formatAmount(amount) {
     // Remove all commas first
     let cleanedAmount = amount.replace(/,/g, '');

     // Split the amount into two parts: the currency symbol and the numerical part
     let parts = cleanedAmount.match(/(\D*)(\d+)(\.\d+)?/);
 
     // Add commas back in the correct place
     let integerPart = parts[2].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
     
     // Combine the parts back together
     let formattedAmount = parts[1] + integerPart + (parts[3] || '');
 
     return formattedAmount;
}


  return (
    <Flex flexDir={"column"} w={"80%"} p={4} m={"auto"}>
      <Text fontSize={26} fontWeight={"600"} color={"#212529"} mb={5}>
      Payments Year to Date
      </Text>
      <Flex w={"100%"} justifyContent={"space-between"}>
        <Flex w={"40%"} alignItems={"center"} mb={4}>
          <Select
            onChange={(e) => setEntriesPerPage(parseInt(e.target.value))}
            w={"18%"}
            mr={1}
            border={"1px solid gray"}
          >
            <option value="10">10</option>
            <option value="25">25</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </Select>
          <Text w={"30%"}>entries per page</Text>
          <Button
            w={"30%"}
            onClick={onOpen}
            size={"sm"}
            color={"white"}
            bg={"blue.400"}
          >
            Add New Payment
          </Button>
        </Flex>

        <Flex mb={4} w={"20%"} alignSelf={"flex-end"} alignItems={"center"}>
          <Text mr={2}>Search:</Text>
          <Input
            type="text"
            border={"1px solid gray"}
            size={"sm"}
            value={searchTerm}
            onChange={handleSearch}
          />
        </Flex>
      </Flex>
      <Box maxH={"400px"} overflowY={"auto"}>
        <Table colorScheme="#212529" size={"sm"}>
          <Thead bg={"#EFEFEF"}>
            <Tr>
              <Th
                textTransform="none"
                cursor="pointer"
                onClick={() => handleSort("Paid Date")}
              >
                <Flex gap={1} alignItems={"center"}>
                  <span style={{ fontSize: "16px" }}>Paid Date</span>{" "}
                  {renderSortIcon("Paid Date")}
                </Flex>
              </Th>
              <Th
                textTransform="none"
                cursor="pointer"
                onClick={() => handleSort("Invoice #")}
              >
                <Flex gap={1} alignItems={"center"}>
                  <span style={{ fontSize: "16px" }}>Invoice #</span>{" "}
                  {renderSortIcon("Invoice #")}
                </Flex>
              </Th>
              <Th
                textTransform="none"
                cursor="pointer"
                onClick={() => handleSort("Type")}
              >
                <Flex gap={1} alignItems={"center"}>
                  <span style={{ fontSize: "16px" }}>Type</span>{" "}
                  {renderSortIcon("Type")}
                </Flex>
              </Th>
              <Th
                textTransform="none"
                cursor="pointer"
                onClick={() => handleSort("Invoice Amount")}
              >
                <Flex gap={1} alignItems={"center"}>
                  <span style={{ fontSize: "16px" }}>Invoice Amount</span>{" "}
                  {renderSortIcon("Invoice Amount")}
                </Flex>
              </Th>
              <Th
                textTransform="none"
                cursor="pointer"
                onClick={() => handleSort("Discounts")}
              >
                <Flex gap={1} alignItems={"center"}>
                  <span style={{ fontSize: "16px" }}>Discounts</span>{" "}
                  {renderSortIcon("Discounts")}
                </Flex>
              </Th>
              <Th
                textTransform="none"
                cursor="pointer"
                onClick={() => handleSort("Amount Paid")}
              >
                <Flex gap={1} alignItems={"center"}>
                  <span style={{ fontSize: "16px" }}>Amount Paid</span>{" "}
                  {renderSortIcon("Amount Paid")}
                </Flex>
              </Th>
            </Tr>
          </Thead>
          <Tbody>
            {paginatedData.length > 0 ? (
              paginatedData.map((el, i) => (
                <Tr key={i}>
                  <Td>{el["Paid Date"]}</Td>
                  <Td>Invoice #{el["Invoice #"]}</Td>
                  <Td>{el.Type}</Td>
                  <Td>{el["Invoice Amount"]}</Td>
                  <Td>{el.Discounts}</Td>
                  <Td>{el["Amount Paid"]}</Td>
                </Tr>
              ))
            ) : (
              <Tr>
                <Td colSpan={6} textAlign="center">
                  No results found
                </Td>
              </Tr>
            )}
          </Tbody>
        </Table>
      </Box>

      <Pagination />

      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Add New Payment</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Flex flexDir="column" gap={3}>
              <Input
                placeholder="Paid Date"
                name="Paid Date"
                value={newData["Paid Date"]}
                onChange={handleInputChange}
              />
              <Input
                placeholder="Invoice #"
                name="Invoice #"
                value={newData["Invoice #"]}
                onChange={handleInputChange}
              />
              <Input
                placeholder="Type"
                name="Type"
                value={newData.Type}
                onChange={handleInputChange}
              />
              <Input
                placeholder="Invoice Amount"
                name="Invoice Amount"
                value={newData["Invoice Amount"]}
                onChange={handleInputChange}
              />
              <Input
                placeholder="Discounts"
                name="Discounts"
                value={newData.Discounts}
                onChange={handleInputChange}
              />
              <Input
                placeholder="Amount Paid"
                name="Amount Paid"
                value={newData["Amount Paid"]}
                onChange={handleInputChange}
              />
            </Flex>
          </ModalBody>

          <ModalFooter>
            <Button colorScheme="blue" mr={3} onClick={handleAddData}>
              Add
            </Button>
            <Button variant="ghost" onClick={onClose}>
              Cancel
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Flex>
  );
};

export default Payments;

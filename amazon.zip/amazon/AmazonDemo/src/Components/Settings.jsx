import React from 'react'

const Settings = () => {
  return (
    <div className='mb-[450px]'>
      <div className="mt-8">
        <div className="bg-teal-100 mx-28 border border-teal-300 text-gray-800 py-4 px-6 rounded shadow">
          <p className="text-start text-lg font-light">
            Please contact your administrator for access to this page.
          </p>
        </div>
      </div>
    </div>
  )
}

export default Settings

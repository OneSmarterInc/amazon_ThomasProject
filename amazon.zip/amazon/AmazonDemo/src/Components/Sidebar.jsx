import React from "react";
import {
  Drawer,
  DrawerBody,
  DrawerFooter,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  useDisclosure,
  Button,
} from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";

const Sidebar = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const navigate = useNavigate();

 
  

  return (
    <div>
      <Button colorScheme="none" onClick={onOpen}>
        <i class="fa-solid fa-bars"></i>
      </Button>
      <Drawer placement={"left"} onClose={onClose} isOpen={isOpen}>
        <DrawerOverlay />
        <DrawerContent>
          <DrawerHeader
            onClick={onClose}
            flex={"row"}
            justifyContent={"end"}
            width={"100%"}
            borderBottomWidth="1px"
          >
            <i class="fa-solid fa-xmark"></i>
          </DrawerHeader>
          <DrawerBody>
            <button
              onClick={() => {
                onClose();
                navigate("/order");
              }}
              className=" text-lg py-2  hover:bg-slate-300 w-full text-start px-4"
            >
              Orders
            </button>
            <button
              onClick={() => {
                onClose();
                navigate("/items");
              }}
              className=" text-lg py-2  hover:bg-slate-300 w-full text-start px-4"
            >
              Items
            </button>
            <button
              onClick={() => {
                onClose();
                navigate("/advertizing");
              }}
              className=" text-lg py-2  hover:bg-slate-300 w-full text-start px-4"
            >
              Advertising
            </button>
            <button
              onClick={() => {
                onClose();
                navigate("/merchandizing");
              }}
              className=" text-lg py-2  hover:bg-slate-300 w-full text-start px-4"
            >
              Merchandising
            </button>
            <button
              onClick={() => {
                onClose();
                navigate("/growth");
              }}
              className=" text-lg py-2  hover:bg-slate-300 w-full text-start px-4"
            >
              Growth
            </button>
            <button
              onClick={() => {
                onClose();
                navigate("/reports");
              }}
              className=" text-lg py-2  hover:bg-slate-300 w-full text-start px-4"
            >
              Reports
            </button>
            <button
              onClick={() => {
                onClose();
                navigate("/payments");
              }}
              className=" text-lg py-2  hover:bg-slate-300 w-full text-start px-4"
            >
              Payments
            </button>
            <button
              onClick={() => {
                onClose();
                navigate("/integration");
              }}
              className=" text-lg py-2  hover:bg-slate-300 w-full text-start px-4"
            >
              Integration
            </button>
            <button onClick={() => {
                onClose();
                navigate("/learn");
              }} className=" text-lg py-2  hover:bg-slate-300 w-full text-start px-4">
              Learn
            </button>
          </DrawerBody>
        </DrawerContent>
      </Drawer>
    </div>
  );
};

export default Sidebar;

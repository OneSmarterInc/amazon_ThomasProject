export  const initialData = [
  {
      "Paid Date": "06/19/2024",
      "Invoice #": 5357110,
      "Type": "TRANSFER",
      "Invoice Amount": "$883,681.63",
      "Discounts": "$-43,964.18",
      "Amount Paid": "$953,437.33"
  },
  {
      "Paid Date": "06/17/2024",
      "Invoice #": 5357009,
      "Type": "TRANSFER",
      "Invoice Amount": "$973,215.27",
      "Discounts": "$-19,777.94",
      "Amount Paid": "$953,437.33"
  },
  {
      "Paid Date": "06/14/2024",
      "Invoice #": 5356697,
      "Type": "TRANSFER",
      "Invoice Amount": "$984,029.91",
      "Discounts": "$-23,616.72",
      "Amount Paid": "$960,413.19"
  },
  {
      "Paid Date": "06/11/2024",
      "Invoice #": 5356902,
      "Type": "TRANSFER",
      "Invoice Amount": "$908,181.63",
      "Discounts": "$-18,116.94",
      "Amount Paid": "$890,064.69"
  },
  {
      "Paid Date": "06/03/2024",
      "Invoice #": 5356738,
      "Type": "TRANSFER",
      "Invoice Amount": "$811,298.41",
      "Discounts": "$-16,301.94",
      "Amount Paid": "$794,996.47"
  },
  {
      "Paid Date": "05/31/2024",
      "Invoice #": 5356768,
      "Type": "TRANSFER",
      "Invoice Amount": "$516,792.53",
      "Discounts": "$-19,616.25",
      "Amount Paid": "$497,176.28"
  },
  {
      "Paid Date": "05/30/2024",
      "Invoice #": 5356768,
      "Type": "TRANSFER",
      "Invoice Amount": "$431,296.42",
      "Discounts": null,
      "Amount Paid": "$431,296.42"
  },
  {
      "Paid Date": "05/22/2024",
      "Invoice #": 5356621,
      "Type": "TRANSFER",
      "Invoice Amount": "$984,716.79",
      "Discounts": "$-24,608.75",
      "Amount Paid": "$960,108.04"
  },
  {
      "Paid Date": "05/17/2024",
      "Invoice #": 5356464,
      "Type": "TRANSFER",
      "Invoice Amount": "$459,815.96",
      "Discounts": "$-18,934.07",
      "Amount Paid": "$440,881.89"
  },
  {
      "Paid Date": "05/15/2024",
      "Invoice #": 5356464,
      "Type": "TRANSFER",
      "Invoice Amount": "$470,073.99",
      "Discounts": null,
      "Amount Paid": "$470,073.99"
  },
  {
      "Paid Date": "05/10/2024",
      "Invoice #": 5356399,
      "Type": "TRANSFER",
      "Invoice Amount": "$550,767.29",
      "Discounts": "$-19,993.64",
      "Amount Paid": "$530,773.65"
  },
  {
      "Paid Date": "05/09/2024",
      "Invoice #": 5356249,
      "Type": "TRANSFER",
      "Invoice Amount": "$535,885.92",
      "Discounts": "$-20,006.93",
      "Amount Paid": "$515,878.99"
  },
  {
      "Paid Date": "05/08/2024",
      "Invoice #": 5356399,
      "Type": "TRANSFER",
      "Invoice Amount": "$407,942.65",
      "Discounts": null,
      "Amount Paid": "$407,942.65"
  },
  {
      "Paid Date": "05/02/2024",
      "Invoice #": 5356249,
      "Type": "TRANSFER",
      "Invoice Amount": "$305,473.83",
      "Discounts": null,
      "Amount Paid": "$305,473.83"
  },
  {
      "Paid Date": "04/30/2024",
      "Invoice #": 5356093,
      "Type": "TRANSFER",
      "Invoice Amount": "$953,307.03",
      "Discounts": "$-21,664.07",
      "Amount Paid": "$931,642.96"
  },
  {
      "Paid Date": "04/29/2024",
      "Invoice #": 5355885,
      "Type": "TRANSFER",
      "Invoice Amount": "$669,597.99",
      "Discounts": "$-18,992.47",
      "Amount Paid": "$650,605.52"
  },
  {
      "Paid Date": "04/25/2024",
      "Invoice #": 5355885,
      "Type": "TRANSFER",
      "Invoice Amount": "$268,777.59",
      "Discounts": null,
      "Amount Paid": "$268,777.59"
  },
  {
      "Paid Date": "04/23/2024",
      "Invoice #": 5355908,
      "Type": "TRANSFER",
      "Invoice Amount": "$894,680.91",
      "Discounts": "$-17,994.63",
      "Amount Paid": "$876,686.28"
  },
  {
      "Paid Date": "04/15/2024",
      "Invoice #": 5355821,
      "Type": "TRANSFER",
      "Invoice Amount": "$987,606.75",
      "Discounts": "$-23,702.76",
      "Amount Paid": "$963,903.99"
  },
  {
      "Paid Date": "04/12/2024",
      "Invoice #": 5355729,
      "Type": "TRANSFER",
      "Invoice Amount": "$420,758.04",
      "Discounts": "$-21,006.82",
      "Amount Paid": "$399,751.22"
  },
  {
      "Paid Date": "04/10/2024",
      "Invoice #": 5355729,
      "Type": "TRANSFER",
      "Invoice Amount": "$503,333.43",
      "Discounts": null,
      "Amount Paid": "$503,333.43"
  },
  {
      "Paid Date": "04/09/2024",
      "Invoice #": 5355686,
      "Type": "TRANSFER",
      "Invoice Amount": "$947,126.25",
      "Discounts": "$-21,616.37",
      "Amount Paid": "$925,509.88"
  },
  {
      "Paid Date": "04/03/2024",
      "Invoice #": 5355629,
      "Type": "TRANSFER",
      "Invoice Amount": "$978,845.25",
      "Discounts": "$-20,404.19",
      "Amount Paid": "$958,441.06"
  },
  {
      "Paid Date": "04/02/2024",
      "Invoice #": 5355605,
      "Type": "TRANSFER",
      "Invoice Amount": "$780,643.93",
      "Discounts": "$13,997.65",
      "Amount Paid": "$794,641.58"
  },
  {
      "Paid Date": "03/27/2024",
      "Invoice #": 5355369,
      "Type": "TRANSFER",
      "Invoice Amount": "$968,530.53",
      "Discounts": "$19,407.06",
      "Amount Paid": "$987,937.59"
  },
  {
      "Paid Date": "03/21/2024",
      "Invoice #": 5355154,
      "Type": "TRANSFER",
      "Invoice Amount": "$555,142.81",
      "Discounts": "$-15,617.94",
      "Amount Paid": "$539,524.87"
  },
  {
      "Paid Date": "03/20/2024",
      "Invoice #": 5355154,
      "Type": "TRANSFER",
      "Invoice Amount": "$345,772.94",
      "Discounts": null,
      "Amount Paid": "$345,772.94"
  },
  {
      "Paid Date": "03/20/2024",
      "Invoice #": 5355008,
      "Type": "TRANSFER",
      "Invoice Amount": "$476,090.77",
      "Discounts": "$-14,888.63",
      "Amount Paid": "$461,202.14"
  },
  {
      "Paid Date": "03/11/2024",
      "Invoice #": 5354729,
      "Type": "TRANSFER",
      "Invoice Amount": "$967,065.75",
      "Discounts": "$-19,555.71",
      "Amount Paid": "$947,510.04"
  },
  {
      "Paid Date": "03/08/2024",
      "Invoice #": 5354642,
      "Type": "TRANSFER",
      "Invoice Amount": "$417,251.38",
      "Discounts": "$-26,452.18",
      "Amount Paid": "$390,799.20"
  },
  {
      "Paid Date": "03/05/2024",
      "Invoice #": 5354642,
      "Type": "TRANSFER",
      "Invoice Amount": "$492,724.99",
      "Discounts": null,
      "Amount Paid": "$492,724.99"
  },
  {
      "Paid Date": "02/27/2024",
      "Invoice #": 5354486,
      "Type": "TRANSFER",
      "Invoice Amount": "$949,837.03",
      "Discounts": "$-158,642.97",
      "Amount Paid": "$791,194.06"
  },
  {
      "Paid Date": "02/20/2024",
      "Invoice #": 5354460,
      "Type": "TRANSFER",
      "Invoice Amount": "$946,047.19",
      "Discounts": "$-56,782.83",
      "Amount Paid": "$889,264.36"
  },
  {
      "Paid Date": "01/26/2024",
      "Invoice #": 5348916,
      "Type": "TRANSFER",
      "Invoice Amount": "$899,178.25",
      "Discounts": "$-53,555.93",
      "Amount Paid": "$845,622.32"
  },
  {
      "Paid Date": "01/24/2024",
      "Invoice #": 5348769,
      "Type": "TRANSFER",
      "Invoice Amount": "$876,624.75",
      "Discounts": "$-52,674.49",
      "Amount Paid": "$823,950.26"
  },
  {
      "Paid Date": "01/23/2024",
      "Invoice #": 5348219,
      "Type": "TRANSFER",
      "Invoice Amount": "$36,000.00",
      "Discounts": null,
      "Amount Paid": "$36,000.00"
  },
  {
      "Paid Date": "01/17/2024",
      "Invoice #": 5349145,
      "Type": "TRANSFER",
      "Invoice Amount": "$467,267.75",
      "Discounts": "$-31,407.19",
      "Amount Paid": "$435,860.56"
  },
  {
      "Paid Date": "01/16/2024",
      "Invoice #": 5348219,
      "Type": "TRANSFER",
      "Invoice Amount": "$904,860.77",
      "Discounts": "$-72,388.86",
      "Amount Paid": "$832,471.91"
  },
  {
      "Paid Date": "01/09/2024",
      "Invoice #": 5349440,
      "Type": "TRANSFER",
      "Invoice Amount": "$887,651.64",
      "Discounts": "$-49,717.31",
      "Amount Paid": "$837,934.33"
  },
  {
      "Paid Date": "01/08/2024",
      "Invoice #": 5348176,
      "Type": "TRANSFER",
      "Invoice Amount": "$919,217.25",
      "Discounts": "$-69,749.12",
      "Amount Paid": "$849,468.13"
  },
  {
      "Paid Date": "01/04/2024",
      "Invoice #": 5346320,
      "Type": "TRANSFER",
      "Invoice Amount": "$923,075.87",
      "Discounts": "$-139,650.51",
      "Amount Paid": "$783,425.36"
  }
]
import React from "react";
import { Route, Routes, useLocation } from "react-router-dom";
import Home from "./Components/Home";
import Navbar from "./Components/Navbar";
import PrivateRoutes from "./PrivateRoutes";
import Order from "./Components/Order";
import Login from "./Components/Login";
import Items from "./Components/Items";
import Advertizing from "./Components/Advertizing";
import Merchandizing from "./Components/Merchandizing";
import Growth from "./Components/Growth";
import Reports from "./Components/Reports";
import Payments from "./Components/Payments";
import Integration from "./Components/Integration";
import Learn from "./Components/Learn";
import Settings from "./Components/Settings";
import Footer from "./Components/Footer";
import NewFile from "./Components/NewFile";

const MainRoutes = () => {
  const location = useLocation();
  return (
    <div>
      {location.pathname !== "/login" && <Navbar />}
      <Routes>
        <Route exact path="/login" element={<Login />} />
        <Route
          exact
          path="/"
          element={
            <PrivateRoutes>
              {" "}
              <Home />
            </PrivateRoutes>
          }
        />
        <Route
          exact
          path="/order"
          element={
            <PrivateRoutes>
              {" "}
              <Order />
            </PrivateRoutes>
          }
        />

        <Route
          exact
          path="/items"
          element={
            <PrivateRoutes>
              {" "}
              <Items />
            </PrivateRoutes>
          }
        />

        <Route
          exact
          path="/advertizing"
          element={
            <PrivateRoutes>
              {" "}
              <Advertizing />
            </PrivateRoutes>
          }
        />

        <Route
          exact
          path="/merchandizing"
          element={
            <PrivateRoutes>
              {" "}
              <Merchandizing />
            </PrivateRoutes>
          }
        />
        <Route
          exact
          path="/growth"
          element={
            <PrivateRoutes>
              {" "}
              <Growth />
            </PrivateRoutes>
          }
        />
        <Route
          exact
          path="/reports"
          element={
            <PrivateRoutes>
              {" "}
              <Reports />
            </PrivateRoutes>
          }
        />
        <Route
          exact
          path="/payments"
          element={
            <PrivateRoutes>
              {" "}
              <Payments />
            </PrivateRoutes>
          }
        />

        <Route
          exact
          path="/integration"
          element={
            <PrivateRoutes>
              {" "}
              <Integration />
            </PrivateRoutes>
          }
        />

        <Route
          exact
          path="/settings"
          element={
            <PrivateRoutes>
              {" "}
              <Settings />
            </PrivateRoutes>
          }
        />

        <Route
          exact
          path="/learn"
          element={
            <PrivateRoutes>
              {" "}
              <Learn />
            </PrivateRoutes>
          }
        />

        <Route
          exact
          path="/new/:name"
          element={
            <PrivateRoutes>
              {" "}
              <NewFile />
            </PrivateRoutes>
          }
        />
      </Routes>
      <Footer />
    </div>
  );
};

export default MainRoutes;

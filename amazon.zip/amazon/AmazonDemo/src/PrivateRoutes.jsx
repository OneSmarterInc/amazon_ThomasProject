import React from "react";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import Cookies from "js-cookie";

const PrivateRoutes = ({ children }) => {
  const location = useLocation();
  console.log("Loc:", location);
  const isAuthenticated = Cookies.get("token"); // Adjust based on your authentication mechanism
  console.log("Is Auth:", isAuthenticated);
  if (isAuthenticated) {
    return children;
  }

  return <Navigate to="/login" />;
};

export default PrivateRoutes;
